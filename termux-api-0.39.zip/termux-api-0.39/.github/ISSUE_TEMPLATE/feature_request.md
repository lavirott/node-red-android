---
name: Feature request
about: Suggest a new feature in termux-api

---

**Feature description**
Describe the feature and why you want it.

**Background information**
Have you checked if the feature is accessible through the android API?
Do you know of other open-source apps that has a similar feature as the one you want? (Provide links)
